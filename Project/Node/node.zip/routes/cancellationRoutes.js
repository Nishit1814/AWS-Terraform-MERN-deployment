const express = require("express");
const router = express.Router();

const { verifyToken } = require("../middleware/auth");
const { createCancellation, getAllCancellations, updateCancellation } = require("../controllers/cancellationController");

router.post("/trip", verifyToken, createCancellation);
router.get("/all", verifyToken, getAllCancellations);
router.put("/update/:id", verifyToken, updateCancellation);

module.exports = router;