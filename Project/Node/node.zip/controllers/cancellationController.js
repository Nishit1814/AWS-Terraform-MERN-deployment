
const Cancellation = require("../models/Cancellation");
const Payment = require("../models/payment");

const createCancellation = async (req, res) => {
    try {
        const userId = req.user.id;

        const {
            tripId,
            paymentId,
            transactionId,
            fullname,
            email,
            phone,
            upiId,
            reason,
            invoicePhoto,
            refundAmount,
            refundPercent,
            diffDays
        } = req.body;

        if (!tripId || !paymentId || !upiId || !reason) {
            return res.status(400).json({ message: "Missing fields" });
        }

        const payment = await Payment.findOne({ _id: paymentId, userId });

        if (!payment) {
            return res.status(404).json({ message: "Invalid payment" });
        }

        const existing = await Cancellation.findOne({ paymentId });

        if (existing) {
            return res.status(400).json({ message: "Already cancelled" });
        }

        const newCancellation = new Cancellation({
            userId,
            tripId,
            paymentId,
            transactionId,
            fullname,
            email,
            phone,
            upiId,
            reason,
            invoicePhoto,
            refundAmount,
            refundPercent,
            diffDays,
            status: "PENDING"
        });

        await newCancellation.save();

        res.status(201).json({
            message: "Cancellation submitted",
            data: newCancellation
        });

    } catch (err) {
        res.status(500).json({ message: "Server error" });
    }
};




const getAllCancellations = async (req, res) => {
    try {
        const cancellations = await Cancellation.find() 
            .populate("userId", "fullname email mobile")
            .populate("tripId", "to startDate")
            .populate("paymentId", "transactionId")
            .sort({ createdAt: -1 });

        // format response (frontend friendly)
        const formatted = cancellations.map(c => ({
            id: c._id,
            fullname: c.fullname || c.userId?.fullname,
            email: c.email || c.userId?.email,
            phone: c.phone || c.userId?.mobile,
            tripTo: c.tripId?.to,
            createdAt: c.createdAt,
            refundAmount: c.refundAmount,
            upiId: c.upiId,
            reason: c.reason,
            status: c.status,
            transactionId: c.paymentId?.transactionId,
            invoicePhoto: c.invoicePhoto,
            paymentId: c.paymentId?._id,
            userId: c.userId?._id
        }));

        res.status(200).json({
            success: true,
            data: formatted
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server error" });
    }
};

const updateCancellation = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, resolution, paymentId, refundTxnId } = req.body;

        const cancellation = await Cancellation.findById(id);

        if (!cancellation) {
            return res.status(404).json({ message: "Cancellation not found" });
        }

        // ✅ update status
        if (status) cancellation.status = status;

        // optional fields
        if (resolution) cancellation.resolution = resolution;

        await cancellation.save();

       
        if (status === "APPROVED" && paymentId) {
            await Payment.findByIdAndUpdate(paymentId, {
                refundStatus: "REFUNDED",
                refundTxnId: refundTxnId
            });
        }

        res.status(200).json({
            message: "Cancellation updated successfully",
            data: cancellation
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "Server error" });
    }
};


module.exports = { createCancellation, getAllCancellations, updateCancellation }